# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array

    def span 
        return nil if self.empty?
        self.max - self.min
    end

    def average
        return nil if self.empty?
        (1.0 * self.sum) / self.length
    end
	
    def median
		return nil if self.empty?
		idx = self.length / 2

		if self.length.odd? 
			return self.sort[idx]
		else 
			sorted = self.sort
			sum = sorted[idx] + sorted[idx-1]
			return sum / 2.0
		end 
	end 

	def counts
		hash = Hash.new(0)
		self.each {|ele| hash[ele] += 1 }
		hash
	end 

	def my_count(n)
        count = 0
        self.each { |ele| count += 1 if n == ele }
        count
    end

    def my_index(val)
        self.each_with_index do |ele, idx|
            return idx if ele == val
        end
        nil
    end

    def my_uniq
        # hash = {}
        # self.each { |el| hash[el] = 0 }
        # hash.keys
		self | self 
    end

require "byebug"

    def my_transpose
		# method_1
        self[0].zip(*self[1..-1])
        
		# method_2 
		# new_arr = Array.new(self.length) {Array.new([]) }
		# self.each_with_index do |subarr, idx1| # idx1:  	0, 0, 0
		# 	subarr.each_with_index do |ele, idx2| # idx2:  	0, 1, 2
		# 		new_arr[idx2] << ele
		# 	end 
		# end 

        # new_arr

		# method_3
		# (0...self.length).map do |i| # 0, 1, 2		
		# 	self.map { |subarr| subarr[i] } 
		# end
    end

end